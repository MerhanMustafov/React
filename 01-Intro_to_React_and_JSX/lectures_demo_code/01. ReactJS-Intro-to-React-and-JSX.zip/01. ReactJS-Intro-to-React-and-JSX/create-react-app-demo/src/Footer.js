function Footer() {
    return <footer>All rights reserved &copy;</footer>
}

// function Footer() {
//     return React.createElement(
//         'div',
//         {},
//         'All rights reserved &copy;'
//     )
// }

export default Footer;
